This directory contains the JOBAD examples. 
All examples can be found in the subdirectory `build`. 
They are auto generated from the `templates` subdirectory. 