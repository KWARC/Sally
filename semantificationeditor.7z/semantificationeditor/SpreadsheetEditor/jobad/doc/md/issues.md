# (Known) Issues

Please report issues at Github: [https://github.com/KWARC/jobad/issues](https://github.com/KWARC/jobad/issues). 
