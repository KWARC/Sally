# Undocumented API
The following API functionailty is currently not documented at all or the documenattion is not up-to-date: 

* `JOBAD.util` - newer util functions are missing, underscore functions not documented locally. 