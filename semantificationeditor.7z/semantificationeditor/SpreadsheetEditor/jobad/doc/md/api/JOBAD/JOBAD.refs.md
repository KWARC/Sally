# JOBAD.refs

* **Object** `JOBAD.refs` - Contains internal references to  JOBADs dependencies
* **Object** `JOBAD.refs.$` - Internal reference to jQuery