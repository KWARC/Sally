# JOBAD.UI.Overlay

* **Function** `JOBAD.UI.Overlay.draw(element)` - Draws an overlay for an element. 
	* **jQuery** `element` Element to draw overlay for. . 
* **Function** `JOBAD.UI.Overlay.undraw(element)` - Undraws an overlay. 
	* **jQuery** `element` Element to remove overlay from. 