# JOBADInstance.Event.contextMenuEntries

* **Function** `.Event.contextMenuEntries.getResult(target)` Get the Result of the contextMenuEntries event handlers. 
	* **jQuery** `target` Element to request context menu on.  
	* **returns** a list of context menu entries. 
