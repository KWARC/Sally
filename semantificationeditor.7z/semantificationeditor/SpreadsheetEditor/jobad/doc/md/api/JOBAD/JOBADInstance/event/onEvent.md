# JOBADInstance.Event.onEvent

* **Function** `.Event.onEvent.getResult(event, element)` Get the Result of the onEvent event handlers. 
	* **string** `event` The event that was triggered. 
	* **jQuery** `element` The element the event was triggred on.  

* **Function** `.Event.onEvent.trigger(event, element)` Trigger the onEvent event. 
	* **string** `event` The event that was triggered. 
	* **jQuery** `element` The element the event was triggred on.  
