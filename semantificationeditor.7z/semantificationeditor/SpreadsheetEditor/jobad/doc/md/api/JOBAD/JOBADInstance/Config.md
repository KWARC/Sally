# JOBADInstance.Config

* **Function** `.Config.set(prop, value)` Updates user configuration. 
	* **String** `prop` Property to set. 
	* **Mixed** `value` Value to set. 

* **Function** `.Config.get(prop)` Reads user configuration. 
	* **String** `prop` Property to get. 
	* **returns** value. 

* **Function** `.Config.reset()` Resets the configuration. 
* **Function** `.Config.getTypes()` Gets the configuration types. 

