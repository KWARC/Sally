# JOBADInstance.Event.leftClick

* **Function** `.Event.leftClick.getResult(target)` Get the Result of the leftClick event handlers. 
	* **jQuery** `target` The element that is being clicked. 
	* **returns** a boolean indicating if some action was taken. 

* **Function** `.Event.leftClick.trigger(target)` Trigger the leftClick event. 
	* **jQuery** `target` The element that is being clicked. 
	* **returns** a boolean indicating if some action was taken. 
