# JOBADInstance.Event.dblClick

* **Function** `.Event.dblClick.getResult(target)` Get the Result of the dblClick event handlers. 
	* **jQuery** `target` The element that is being double clicked. 
	* **returns** a boolean indicating if some action was taken. 

* **Function** `.Event.dblClick.trigger(target)` Trigger the dblClick event. 
	* **jQuery** `target` The element that is being double clicked. 
	* **returns** a boolean indicating if some action was taken. 
