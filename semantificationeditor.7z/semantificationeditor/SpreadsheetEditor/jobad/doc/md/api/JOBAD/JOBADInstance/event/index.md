# JOBADInstance.Event

* **Object** [`.Event.dblClick`](dblClick.md) Namespace for dblClick Events. 
* **Object** [`.Event.leftClick`](leftClick.md) Namespace for leftClick Events. 
* **Object** [`.Event.contextMenuEntries`](contextMenuEntries.md) Namespace for contextMenuEntries Events. 
* **Object** [`.Event.hoverText`](hoverText.md) Namespace for hoverText Events. 
* **Object** [`.Event.configUpdate`](configUpdate.md) Namespace for onConfigUpdate Events. 
* **Object** [`.Event.onSideBarUpdate`](onSideBarUpdate.md) Namespace for onSideBarUpdate Events. 
* **Object** [`.Event.onEvent`](onEvent.md) Namespace for onEvent Events. 


## See also

* [`JOBAD.events`](../../JOBAD.events/index.md)
