# JOBAD.console

* **Function** `JOBAD.console.log(msg)` - Produces a log message in the console if available
	* **String** `msg` Message content
* **Function** `JOBAD.console.warn(msg)` - Produces a warning message in the console if available
	* **String** `msg` Message content
* **Function** `JOBAD.console.error(msg)` - Produces a error message in the console if available
	* **String** `msg` Message content