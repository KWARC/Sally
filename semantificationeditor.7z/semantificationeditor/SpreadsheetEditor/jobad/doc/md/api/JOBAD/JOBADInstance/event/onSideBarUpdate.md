# JOBADInstance.Event.SideBarUpdate

* **Function** `.Event.SideBarUpdate.getResult()` Get the Result of the SideBarUpdate event handlers. 

* **Function** `.Event.SideBarUpdate.trigger()` Trigger the SideBarUpdate event. 

## See also
* [`JOBADInstance.Sidebar`](../sidebar.md)
