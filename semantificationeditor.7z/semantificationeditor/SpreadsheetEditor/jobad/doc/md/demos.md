# Demos

Here you can find examples of JOBAD. 

* simple - A very simple JOBAD example. 
	* [Release version](./../../examples/build/simple/release.html)
	* [Development version](./../../examples/build/simple/dev.html)
	* [Unbuilt version](./../../examples/build/simple/unbuilt.html)
* math - A math example. Supposed to demo Folding. 
	* [Release version](./../../examples/build/math/release.html)
	* [Development version](./../../examples/build/math/dev.html)
	* [Unbuilt version](./../../examples/build/math/unbuilt.html)
