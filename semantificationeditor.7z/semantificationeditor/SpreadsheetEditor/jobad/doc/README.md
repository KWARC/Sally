This directory contains the JOBAD documentation. The JOBAD doc is auto generated in html format from .md files which can be found in the md subdirectory. 
