var mockdata = [
                  {
                      "workbook": [{
                          "bookname":"SimplePricingxlsx",

                          "vendor": [
                              {
                                  "name": "Price",
                                  "range": "A4:A11",
                                  "meaning": "blahblah"
                              },
                              {
                                  "name": "Price",
                                  "range": "A4:A12",
                                  "meaning": "blahblah"
                              },
                              {
                                  "name": "Price",
                                  "range": "A4:A13",
                                  "meaning": "blahblah"
                              }
                          ],
                          "customer": [
                              {
                                  "name": "CustomerA",
                                  "range": "A3:A9",
                                  "meaning": "Price per piece"
                              },
                              {
                                  "name": "Price",
                                  "range": "A4:A11",
                                  "meaning": "blahblah"
                              },
                              {
                                  "name": "CustomerC",
                                  "range": "A3:A9",
                                  "meaning": "Price per piece"
                              }
                          ]
                        }
                      ]
                  }
              ];



// generates the block table contents
// $.getJSON('mockjsonfromsally.json', function(mockdata){
  $( document ).ready(initScan);
 
  function getBookName(){
    for (var i in mockdata){
      return mockdata[i];
    }
  }

  function getSheetNames(){
    //return 
  } 
  
  function initScan(){
    console.log(getBookName());
    fillBlocksTable("vendor");
  }

  function fillBlocksTable(sheetName){
    
    var tfrag = $("<tr>");

    var temprow = "{{#"+sheetName+"}}<tr><td><\/td><td><input id=\"new-concept\" type=\"text\" value={{name}} class=\"span12\"><\/td><td><input id=\"new-range\" type=\"text\" value={{range}} class=\"span12\"><\/td>\r\n<td><span class=\"span16 uri\" id=\"new-meaning\" type=\"text\" class=\"span12\">{{meaning}}<\/span><\/td><\/tr>{{/"+sheetName+"}}";

    var htmlrow;
    
    htmlrow = $.parseHTML(Mustache.render(temprow, mockdata[0].SimplePricingxlsx));
    
    tfrag.append(htmlrow);
    
    tblappender(htmlrow);
  }

  function fillRelationsTable(){

  }

  function tblappender(fragment){
    $("#todo-list").append(fragment); 
  }  




  //$.each(mockdata, function(i, item) {
  //});


  // tr.appendChild(tdsfrag);
  // trsfrag.appendChild(tr);  
//});

function setAttributes(el, attrs) {
  for(var key in attrs) {
    el.setAttribute(key, attrs[key]);
  }
  return el;
}
